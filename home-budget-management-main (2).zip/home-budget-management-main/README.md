# home-budget-management


This website is for tracking our expense through our expense and budget input.

to run this code on localhost follow the below commands.

1. download the given files in folder and name it expense.

2. now cd folder like 
-> cd folder

3. Install virtual environment
-> pip install virtualenv

4. create environment and activate it
   -> virtualenv env
   -> env\Scripts\activate
   
4. run django server
   -> cd expense
   -> python manage.py runserver
    
Copy the given link and open it in browser like link/register/ 



video demo -
https://drive.google.com/file/d/1sjpsWSP30GToIgeVKnn2f3N9hmMAsofI/view?usp=drivesdk
